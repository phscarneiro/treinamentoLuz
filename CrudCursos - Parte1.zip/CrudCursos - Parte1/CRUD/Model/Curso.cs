﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUD.Model
{
    public class Curso : Notifica, ICloneable
    {
        private int _id;
        public int Id
        {
            get { return _id; }
            set { SetField(ref _id, value); }
        }

        private string _nome;
        public string Nome
        {
            get { return _nome; }
            set { SetField(ref _nome, value); }
        }

        private string _autor;
        public string Autor
        {
            get { return _autor; }
            set { SetField(ref _autor, value); }
        }

        private DateTime _dataInicio;
        public DateTime DataInicio
        {
            get { return _dataInicio; }
            set { SetField(ref _dataInicio, value); }
        }

        private Nivel _nivel;
        public Nivel Nivel
        {
            get { return _nivel; }
            set { SetField(ref _nivel, value); }
        }

        private Area _area;
        public Area Area
        {
            get { return _area; }
            set { SetField(ref _area, value); }
        }

        private string _local;
        public string Local
        {
            get { return _local; }
            set { SetField(ref _local, value); }
        }

        private string _duracao;
        public string Duracao
        {
            get { return _duracao; }
            set { SetField(ref _duracao, value); }
        }
        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
