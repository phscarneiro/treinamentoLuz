﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace CRUD.ViewModel
{   
    
    public class CursoVM : Notifica
    {
        // funcoes parametro do relaycomand
        public bool PodeDeletar(object parametro)
        {
            var viewModel = parametro as CursoVM;
            return viewModel != null && viewModel.CursoSelecionado != null;
        }

        public void Deletar(object parametro)
        {
            var viewModel = (CursoVM)parametro;
            viewModel.Cursos.Remove(viewModel.CursoSelecionado);
            viewModel.CursoSelecionado = viewModel.Cursos.FirstOrDefault();
        }

        public bool PodeEditar(object parametro)
        {
            var viewModel = parametro as CursoVM;
            return viewModel != null && viewModel.CursoSelecionado != null;
        }

        public void Editar(object parametro)
        {
            var viewModel = (CursoVM)parametro;
            var cloneCurso = (Model.Curso)viewModel.CursoSelecionado.Clone();
            var fw = new CursoJanela();
            fw.DataContext = cloneCurso;
            fw.ShowDialog();

            if (fw.DialogResult.HasValue && fw.DialogResult.Value)
            {
                viewModel.CursoSelecionado.Nome = cloneCurso.Nome;
                viewModel.CursoSelecionado.Autor = cloneCurso.Autor;
                viewModel.CursoSelecionado.DataInicio = cloneCurso.DataInicio;
                viewModel.CursoSelecionado.Nivel = cloneCurso.Nivel;
                viewModel.CursoSelecionado.Area = cloneCurso.Area;
                viewModel.CursoSelecionado.Duracao = cloneCurso.Duracao;
                viewModel.CursoSelecionado.Local = cloneCurso.Local;
            }
        }

        public bool PodeNovo(object parametro)
        {
            return parametro is CursoVM;
        }

        public void Novo(object parametro)
        {
            var viewModel = (CursoVM)parametro;
            var curso = new Model.Curso();
            var maxId = 0;
            if (viewModel.Cursos.Any())
            {
                maxId = viewModel.Cursos.Max(f => f.Id);
            }
            curso.Id = maxId + 1;

            var fw = new CursoJanela();
            fw.DataContext = curso;
            fw.ShowDialog();

            if (fw.DialogResult.HasValue && fw.DialogResult.Value)
            {
                viewModel.Cursos.Add(curso);
                viewModel.CursoSelecionado = curso;
            }
        }
        //fim funcoes parametro

        public ObservableCollection<Model.Curso> Cursos { get; private set; }

        public ICommand NovoComando { get; private set; }
        public ICommand EditarComando { get; private set; }
        public ICommand DeletarComando { get; private set; }

        private Model.Curso _cursoSelecionado;
        public Model.Curso CursoSelecionado
        {
            get { return _cursoSelecionado; }
            set { 
                SetField(ref _cursoSelecionado, value);
            }
        }
        
        public CursoVM()
        {
            Cursos = new ObservableCollection<Model.Curso>();
            Cursos.Add(new Model.Curso()
            {
                Id = 1,
                Nome = "Pedro",
                Autor = "Carneiro",
                DataInicio = new DateTime(1900, 1, 1),
                Nivel = Model.Nivel.Intermediario,
                Area = Model.Area.TI,
                Local = "linkedin",
                Duracao = "120h"
            });

            CursoSelecionado = Cursos.FirstOrDefault();

            NovoComando = new RelayCommand(Novo, PodeNovo);
            EditarComando = new RelayCommand(Editar, PodeEditar);
            DeletarComando = new RelayCommand(Deletar, PodeDeletar);

         }

    }
}
